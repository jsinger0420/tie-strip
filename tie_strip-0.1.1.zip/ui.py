"""The Tie Strip tab in the 3D Viewport sidebar (N panel)."""

import bpy

from . import layout, plates, preset_store, wb_bridge


def _s(context):
    return context.scene.tie_strip


def _u(s):
    return "in" if s.proto_units == "IN" else "mm"


# ---- menus ----

class TIESTRIP_MT_board_presets(bpy.types.Menu):
    bl_label = "Weathered Board Presets"
    bl_idname = "TIESTRIP_MT_board_presets"

    def draw(self, context):
        names = wb_bridge.preset_names()
        if not names:
            self.layout.label(text=wb_bridge.available() or "No presets found", icon="ERROR")
        for name, _desc in names:
            self.layout.operator("tie_strip.set_board_preset", text=name).name = name


class TIESTRIP_MT_plate_presets(bpy.types.Menu):
    bl_label = "Tie Plate Presets"
    bl_idname = "TIESTRIP_MT_plate_presets"

    def draw(self, context):
        col = self.layout
        for p in plates.BUILTIN_PLATES:
            col.operator("tie_strip.apply_plate_preset", text=p.name).name = p.name
        saved = preset_store.saved_names(preset_store.PLATE)
        if saved:
            col.separator()
            for name in saved:
                row = col.row(align=True)
                row.operator("tie_strip.apply_plate_preset", text=name).name = name
                row.operator("tie_strip.remove_plate_preset", text="", icon="X").name = name


class TIESTRIP_MT_strip_presets(bpy.types.Menu):
    bl_label = "Strip Presets"
    bl_idname = "TIESTRIP_MT_strip_presets"

    def draw(self, context):
        saved = preset_store.saved_names(preset_store.STRIP)
        if not saved:
            self.layout.label(text="No strip presets saved yet")
        for name in saved:
            row = self.layout.row(align=True)
            row.operator("tie_strip.apply_strip_preset", text=name).name = name
            row.operator("tie_strip.remove_strip_preset", text="", icon="X").name = name


def _preset_row(layout, menu, label, current, modified, save_op):
    row = layout.row(align=True)
    text = (current or label) + (" (modified)" if current and modified else "")
    row.menu(menu, text=text)
    row.operator(save_op, text="", icon="ADD")


# ---- panels ----

class _Panel:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tie Strip"


class TIESTRIP_PT_main(_Panel, bpy.types.Panel):
    bl_label = "Tie Strip"

    def draw(self, context):
        s = _s(context)
        col = self.layout.column()
        _preset_row(col, "TIESTRIP_MT_strip_presets", "Strip Presets", s.strip_preset,
                    s.strip_modified, "tie_strip.save_strip_preset")
        missing = wb_bridge.available()
        if missing:
            box = col.box()
            box.alert = True
            box.label(text=missing, icon="ERROR")
        row = col.row(align=True)
        row.scale_y = 1.4
        row.enabled = not missing
        row.operator("tie_strip.generate", icon="MESH_GRID")
        col.operator("tie_strip.export_stl", icon="EXPORT")
        if s.last_report:
            col.label(text=s.last_report)

        lay = layout.compute(s.to_spec())
        box = col.box()
        if lay.errors:
            box.alert = True
            for e in lay.errors:
                box.label(text=e, icon="ERROR")
            return
        m = lay.summary
        box.label(text="Model size", icon="INFO")
        box.label(text=f"Tie {m['tie_length']:.2f} x {m['tie_width']:.2f} x {m['tie_height']:.2f} mm")
        box.label(text=f"Gap between ties {m['gap']:.2f} mm")
        box.label(text=f"Printed size {m['overall_length']:.1f} x {m['overall_width']:.1f} x "
                       f"{m['top']:.2f} mm ({len(lay.tie_x)} ties)")
        box.label(text=f"Rail centres at +/-{m['rail_centre']:.2f} mm")
        box.label(text=f"Outer hole edge at +/-{m['outer_hole']:.2f} mm")
        for w in lay.warnings:
            box.label(text=w, icon="ERROR")


class TIESTRIP_PT_track(_Panel, bpy.types.Panel):
    bl_label = "Scale and Track"
    bl_parent_id = "TIESTRIP_PT_main"

    def draw(self, context):
        s = _s(context)
        col = self.layout.column()
        col.prop(s, "scale")
        if s.scale == "CUSTOM":
            col.prop(s, "scale_custom")
        col.label(text="Measured on your rail (mm):")
        col.prop(s, "gauge", text="Gauge (mm)")
        col.prop(s, "rail_foot", text="Foot Width (mm)")
        col.prop(s, "rail_head", text="Head Width (mm)")


class TIESTRIP_PT_ties(_Panel, bpy.types.Panel):
    bl_label = "Ties"
    bl_parent_id = "TIESTRIP_PT_main"

    def draw(self, context):
        s, u = _s(context), _u(_s(context))
        col = self.layout.column()
        col.prop(s, "proto_units")
        col.prop(s, "tie_length", text=f"Length ({u})")
        col.prop(s, "tie_width", text=f"Width ({u})")
        col.prop(s, "tie_height", text=f"Height ({u})")
        col.prop(s, "tie_spacing", text=f"Spacing ({u})")
        col.prop(s, "size_mode", expand=True)
        if s.size_mode == "LENGTH":
            col.prop(s, "max_length", text="Max Length (mm)")
            n = s.ties()
            row = col.row()
            row.alert = n < 2
            row.label(text=f"{n} ties fit" if n >= 2 else "Not even 2 ties fit",
                      icon="INFO" if n >= 2 else "ERROR")
        else:
            col.prop(s, "tie_count")


class TIESTRIP_PT_strip(_Panel, bpy.types.Panel):
    bl_label = "Strip"
    bl_parent_id = "TIESTRIP_PT_main"

    def draw(self, context):
        s = _s(context)
        col = self.layout.column()
        col.prop(s, "strip_type", expand=True)
        if s.strip_type == "FLEX":
            col.prop(s, "flex_first")
        col.prop(s, "connector_width", text="Connector Width (mm)")
        col.prop(s, "connector_height")
        col.prop(s, "seat_pad")


class TIESTRIP_PT_boards(_Panel, bpy.types.Panel):
    bl_label = "Boards"
    bl_parent_id = "TIESTRIP_PT_main"

    def draw(self, context):
        s = _s(context)
        col = self.layout.column()
        col.menu("TIESTRIP_MT_board_presets", text=s.board_preset or "Choose a preset")
        col.prop(s, "printer", expand=True)
        row = col.row(align=True)
        row.prop(s, "seed")
        row.operator("tie_strip.new_seed", text="", icon="FILE_REFRESH")
        col.prop(s, "max_triangles")
        col.prop(s, "pool_threshold")
        sub = col.column()
        sub.enabled = s.ties() > s.pool_threshold
        sub.prop(s, "pool_size")


class TIESTRIP_PT_variation(_Panel, bpy.types.Panel):
    bl_label = "Variation"
    bl_parent_id = "TIESTRIP_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        s, u = _s(context), _u(_s(context))
        col = self.layout.column()
        col.prop(s, "length_jitter", text=f"Length +/- ({u})")
        col.prop(s, "end_jitter", text=f"End Offset +/- ({u})")
        col.prop(s, "yaw_jitter", text="Angle +/- (degrees)")
        col.prop(s, "random_turn")


class TIESTRIP_PT_holes(_Panel, bpy.types.Panel):
    bl_label = "Spike Holes"
    bl_parent_id = "TIESTRIP_PT_main"

    def draw(self, context):
        s, u = _s(context), _u(_s(context))
        col = self.layout.column()
        col.prop(s, "hole_diameter", text="Diameter (mm)")
        col.prop(s, "hole_clearance", text="Clearance from Foot (mm)")
        col.prop(s, "use_stagger")
        sub = col.column()
        sub.enabled = s.use_stagger
        sub.prop(s, "stagger", text=f"Stagger ({u})")


class TIESTRIP_PT_plates(_Panel, bpy.types.Panel):
    bl_label = "Tie Plates"
    bl_parent_id = "TIESTRIP_PT_main"

    def draw_header(self, context):
        self.layout.prop(_s(context), "plates_on", text="")

    def draw(self, context):
        s, u = _s(context), _u(_s(context))
        col = self.layout.column()
        _preset_row(col, "TIESTRIP_MT_plate_presets", "Plate Presets", s.plate_preset,
                    s.plate_modified, "tie_strip.save_plate_preset")
        body = col.column()
        body.enabled = s.plates_on
        body.prop(s, "plate_length", text=f"Length ({u})")
        body.prop(s, "plate_width", text=f"Width ({u})")
        body.prop(s, "plate_thickness", text=f"Thickness ({u})")
        body.prop(s, "plate_bias", text=f"Field-Side Bias ({u})")
        body.prop(s, "shoulders")
        sub = body.column()
        sub.enabled = s.shoulders != "NONE"
        sub.prop(s, "shoulder_height", text=f"Shoulder Height ({u})")
        sub.prop(s, "shoulder_width", text=f"Shoulder Width ({u})")
        sub.prop(s, "shoulder_clearance", text="Shoulder Clearance (mm)")


classes = (
    TIESTRIP_MT_board_presets, TIESTRIP_MT_plate_presets, TIESTRIP_MT_strip_presets,
    TIESTRIP_PT_main, TIESTRIP_PT_track, TIESTRIP_PT_ties, TIESTRIP_PT_strip,
    TIESTRIP_PT_boards, TIESTRIP_PT_variation, TIESTRIP_PT_holes, TIESTRIP_PT_plates,
)
